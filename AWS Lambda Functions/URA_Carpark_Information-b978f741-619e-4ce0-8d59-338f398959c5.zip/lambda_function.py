from svy21 import SVY21
import simplejson as json

import botocore
import urllib3
import boto3
from botocore.exceptions import ClientError
from datetime import datetime

dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')

def get_secret(secret):
    secret_name = secret
    region_name = "ap-southeast-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            return secret
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            return decoded_binary_secret

# Bulk insert URA carpark data into carpark details table
def insert_URA_data(dictList):
    table = dynamodb.Table('CarparkDetails')
    with table.batch_writer() as batch:
        for key in dictList.keys():
            batch.put_item(
                Item=dictList[key]
            )


# Create new dictionary with self defined data structure, converted from the api data
def restructure_URA_carpark_data(dataList):
    converter = SVY21()
    result_dict = {}
    for record in dataList:
        if not ('geometries' in record.keys()):
            continue

        if record['ppCode'] in result_dict.keys():
            rate_dict = {'start_time': record['startTime'],
                         'end_time': record['endTime'],
                         'weekday_rate': record['weekdayRate'],
                         'weekday_min': record['weekdayMin'],
                         'satday_rate': record['satdayRate'],
                         'satday_min': record['satdayMin'],
                         'sunPH_rate': record['sunPHRate'],
                         'sunPH_min': record['sunPHMin']}
            if "remarks" in record.keys():
                rate_dict['remarks'] = record['remarks']
            if record['vehCat'] == 'Car':
                result_dict[record['ppCode']]['Rates']['Car'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Car'] = record['parkCapacity']
            if record['vehCat'] == 'Motorcycle':
                result_dict[record['ppCode']]['Rates']['Motorcycle'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Motorcycle'] = record['parkCapacity']
            if record['vehCat'] == 'Heavy Vehicle':
                result_dict[record['ppCode']]['Rates']['Heavy_Vehicle'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Heavy_Vehicle'] = record['parkCapacity']

        else:
            try:
                coordinates = record['geometries'][0]['coordinates'].split(',')
            except IndexError as e:
                print(e)
                print("Coordinates do not exist, skipping...")
                continue
            # TODO swap the coordinates! ive done it alr, just take note only and update the db
            lat, lon = converter.computeLatLon(float(coordinates[1]), float(coordinates[0]))
            location = str(lat) + ' ' + str(lon)
            value = {
                'CarParkID': record['ppCode'],
                'Name': record['ppName'],
                'Location': location,
                'TotalLots': {
                    'Car': 0,
                    'Motorcycle': 0,
                    'Heavy_Vehicle': 0
                },
                'Agency': 'URA',
                'Details': {
                    'type_of_parking_system': record['parkingSystem'],
                },
                'Rates': {'Car': [],
                          'Motorcycle': [],
                          'Heavy_Vehicle': []
                          }
            }
            rate_dict = {'start_time': record['startTime'],
                         'end_time': record['endTime'],
                         'weekday_rate': record['weekdayRate'],
                         'weekday_min': record['weekdayMin'],
                         'satday_rate': record['satdayRate'],
                         'satday_min': record['satdayMin'],
                         'sunPH_rate': record['sunPHRate'],
                         'sunPH_min': record['sunPHMin']}
            if "remarks" in record.keys():
                rate_dict['remarks'] = record['remarks']

            if record['vehCat'] == 'Car':
                value['Rates']['Car'].append(rate_dict)
                value['TotalLots']['Car'] = record['parkCapacity']
            if record['vehCat'] == 'Motorcycle':
                value['Rates']['Motorcycle'].append(rate_dict)
                value['TotalLots']['Motorcycle'] = record['parkCapacity']
            if record['vehCat'] == 'Heavy Vehicle':
                value['Rates']['Heavy_Vehicle'].append(rate_dict)
                value['TotalLots']['Heavy_Vehicle'] = record['parkCapacity']
            result_dict[record['ppCode']] = value
    return result_dict


# Obtain the URA carpark details from api
def lambda_handler(event, context):
    # calls the function to retrieve secret from aws secret manager, need special role to do this

    secret = json.loads(get_secret("URAAccountKey"))
    URAToken = get_secret("URAToken")

    # API call
    data_url = "https://www.ura.gov.sg/uraDataService/invokeUraDS?service=Car_Park_Details"
    http = urllib3.PoolManager()

    response = http.request('GET',
                            data_url,
                            headers={'AccessKey': secret['URAAccountKey'],
                                     'Token': URAToken,
                                     'Content-Type': 'application/json'},
                            retries=False)

    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        result = restructure_URA_carpark_data(data['Result'])
        insert_URA_data(result)
        return {
            'statusCode': 200,
            'body': json.dumps('URA Carpark information updated')
        }

