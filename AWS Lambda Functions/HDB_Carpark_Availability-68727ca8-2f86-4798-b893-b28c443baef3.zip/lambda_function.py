import json
import urllib3
import boto3
import botocore
from botocore.exceptions import ClientError
import os

dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')
def duplicate_checker_HDB(dataList):
    dataDict = {}
    for record in dataList:
        if (record['carpark_number']) in dataDict.keys():
            # car park already exists in dataDict
            continue
        dataDict[record['carpark_number']] = record
    return dataDict
    
def insert_HDB_Lot_data(dictList):
    table = dynamodb.Table('HDB_Lots')
    with table.batch_writer() as batch:
        for key in dictList.keys():
            try:
                batch.put_item(
                    Item={
                        'CarParkID': dictList[key]['carpark_number'],
                        'LotType': dictList[key]['carpark_info'][0]['lot_type'],
                        'TotalLots': dictList[key]['carpark_info'][0]['total_lots'],
                        'AvailableLots': dictList[key]['carpark_info'][0]['lots_available'],
                        'UpdateTime': dictList[key]['update_datetime'],
                    }
                )
            except botocore.exceptions.ClientError as error:
                print(error)
                print(dictList[key])

def lambda_handler(event, context):

    # API call
    url = "https://api.data.gov.sg/v1/transport/carpark-availability"

    http = urllib3.PoolManager()

    response = http.request('GET',
                            url,
                            headers={'Content-Type': 'application/json'},
                            retries=False)
    
    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        HDBdict = duplicate_checker_HDB(data['items'][0]['carpark_data'])
        insert_HDB_Lot_data(HDBdict)
        return {
        'statusCode': 200,
        'body': json.dumps('HDB car park data is updated!')
        }

