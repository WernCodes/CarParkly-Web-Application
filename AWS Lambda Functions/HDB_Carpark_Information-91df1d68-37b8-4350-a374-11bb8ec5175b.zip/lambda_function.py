import json
import os
import boto3
import botocore
import urllib3
from botocore.exceptions import ClientError

from svy21 import *

dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')
HDB_Central_Carparks = ['ACB', 'BBB', 'BRB1', 'CY', 'DUXM', 'HLM', 'KAB', 'KAM', 'KAS', 'PRM', 'SLS', 'SR1', 'SR2',
                        'TPM', 'UCS', 'WCB']


# //////////////////////////////////////////////////////////////////////////////////////
# Initial Data population Code

# Bulk insert data to carpark details table
def insert_HDB_data(dataList):
    converter = SVY21()
    
    table = dynamodb.Table('CarparkDetails')
    with table.batch_writer() as batch:
        for record in dataList:
            is_central = False
            if record['car_park_no'] in HDB_Central_Carparks:
                is_central = True

            lat, lon = converter.computeLatLon(float(record['y_coord']), float(record['x_coord']))
            location = str(lat) + ' ' + str(lon)
            
            batch.put_item(
                Item={
                    'CarParkID': record['car_park_no'],
                    'Name': record['address'],
                    'Location': location,
                    'Agency': 'HDB',
                    'Details': {
                        'is_central': is_central,
                        'type_of_parking_system': record['type_of_parking_system'],
                        'car_park_type': record['car_park_type'],
                        'car_park_basement': record['car_park_basement'],
                        'car_park_decks': record['car_park_decks'],
                        'gantry_height': record['gantry_height'],
                    },
                    'Rates': {
                        'free_parking': record['free_parking'],
                        'night_parking': record['night_parking'],
                        'short_term_parking': record['short_term_parking'],
                    }
                }
            )


# API call to retrieve HDB Carpark details
def lambda_handler(event, context):

    # API call
    url = "https://data.gov.sg/api/action/datastore_search?resource_id=139a3035-e624-4f56-b63f-89ae28d4ae4c&"
    parameter = "offset="
    currentCount = 0

    http = urllib3.PoolManager()
    while True:
        response = http.request('GET',
                                url + parameter + str(currentCount),
                                headers={'Content-Type': 'application/json'},
                                retries=False)

        print(currentCount)

        if response.status == 200:
            data = json.loads(response.data.decode('utf8'))
            if (len(data['result']['records'])) < 100:
                insert_HDB_data(data['result']['records'])
                return {
                'statusCode': 200,
                'body': json.dumps('HDB Carpark info retreived and updated')
                }
            else:
                # Call insert data function to create new records of carparks in dynamodb
                insert_HDB_data(data['result']['records'])
                currentCount += 100
