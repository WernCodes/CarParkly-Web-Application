from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from geopy.geocoders import Nominatim


def waitforelement(css, webdriver):
    element = WebDriverWait(webdriver, 15).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, css)))


def create_list(table_items):
    result_list = []
    for table_item in table_items:
        row_items = table_item.find_elements(By.TAG_NAME, "td")

        carpark_dict = {
            'Name': row_items[0].text,
            'Rates': {
                'Weekdays before 5/6pm': row_items[1].text,
                'Weekdays after 5/6pm': row_items[2].text,
                'Saturdays': row_items[3].text,
                'Sundays/Public Holidays': row_items[4].text,
            }
        }
        result_list.append(carpark_dict)
    return result_list


def geocode(carparkList):
    geolocator = Nominatim(user_agent="carparkGeoCode")
    for carpark in carparkList:
        addr = carpark['Name']
        
        try:
            location = geolocator.geocode(addr, country_codes=['SG'])
            print("Latitude and Longitude of the address:")
            print((location.latitude, location.longitude))
            latlon = str(location.latitude) + ' ' + str(location.longitude)
            carpark['Location'] = latlon
        except:
            try:
                x = addr.split("(")
                location = geolocator.geocode(x[0], country_codes=['SG'])
                print("Latitude and Longitude of the address:")
                print((location.latitude, location.longitude))
                latlon = str(location.latitude) + ' ' + str(location.longitude)
                carpark['Location'] = latlon
            except:
                try:
                    x = addr.split(",")
                    location = geolocator.geocode(x[0], country_codes=['SG'])
                    print("Latitude and Longitude of the address:")
                    print((location.latitude, location.longitude))
                    latlon = str(location.latitude) + ' ' + str(location.longitude)
                    carpark['Location'] = latlon
                except:
                    print("unable to process address, moving on")
