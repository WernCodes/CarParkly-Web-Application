# import libraries here

import boto3


dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')


# insert_data function for inserting data into dynamodb table
def insert_LTA_data(dataList):
    table = dynamodb.Table('CarparkDetails')  # pylint: disable=E1101
    with table.batch_writer() as batch:
        for i in range(len(dataList)):
            record = dataList[i]
            batch.put_item(
                Item={
                    'CarParkID': record['CarParkID'],
                    'Name': record['Name'],
                    'Location': record['Location'],
                    'Agency': 'LTA',
                    'Rates': record['Rates']
                }
            )

