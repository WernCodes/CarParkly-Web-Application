import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import sys
import time
from DB_update import insert_LTA_data
from scraper_functions import waitforelement, create_list, geocode

drop_down = 'body > div.content_container.app-content > main > div.standard-content > div > div > div.parking_list > div'
drop_down_list = 'body > div.content_container.app-content > main > div.standard-content > div > div > div.parking_list > div > ul'
table = 'body > div.content_container.app-content > main > div.standard-content > div > div > table'
table_body = 'body > div.content_container.app-content > main > div.standard-content > div > div > table > tbody'


def lambda_handler(event, context):
    options = Options()
    options.binary_location = '/opt/headless-chromium'
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--single-process')
    options.add_argument('--disable-dev-shm-usage')
    driver = webdriver.Chrome('/opt/chromedriver',chrome_options=options)
    driver.get(
        "https://onemotoring.lta.gov.sg/content/onemotoring/home/owning/ongoing-car-costs/parking/parking_rates.1.html")
    index = 0

    # range(8) because there are 7 options in the drop down list
    for i in range(8):
        waitforelement(drop_down, driver)
        # click drop down menu
        try:
            linkElem = driver.find_element(By.CSS_SELECTOR, drop_down)
            print('Found the element with that class name!')
            linkElem.click()
        except:
            print('Was not able to find an element with that name.')
            sys.exit("Error in clicking the drop down list")
    
        waitforelement(drop_down_list, driver)
        try:
            listElem = driver.find_element(By.CSS_SELECTOR, drop_down_list)
            print('Found the element with that class name!')
            items = listElem.find_elements(By.TAG_NAME, "li")
            items[i].click()
        except:
            print('Was not able to find an element with that name.')
            sys.exit("Error in clicking the element in drop down list")
    
        waitforelement(table, driver)
    
        try:
            table_body_elem = driver.find_element(By.CSS_SELECTOR, table_body)
            print('Found the element with that class name!')
            table_items = table_body_elem.find_elements(By.TAG_NAME, "tr")
            
            carpark_list = create_list(table_items)
    
        except:
            print('Was not able to find an element with that name.')
            sys.exit("Error in creating list of car parks")
    
        geocode(carpark_list)
    
        # carparks that were not able to retrieve location for would only have 2 keys, so we ignore them from db
        cleaned_carpark_list = list(filter(lambda carprk: len(carprk) == 3,
                                           carpark_list)
                                    )
        for carpark in cleaned_carpark_list:
            carpark['CarParkID'] = 'SCSE' + str(index)
            index += 1
        insert_LTA_data(cleaned_carpark_list)
    
    

    driver.quit()
    return {
        'statusCode': 200,
        'body': json.dumps(cleaned_carpark_list)
    }
    