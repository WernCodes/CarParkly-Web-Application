from api.carpark_filter_service import *
from api.carpark_service import *
from api.community_reviews_service import editVotes, getReviews, addReview
from api.cost_calculator import *
from api.user_account_service import register, login, confirm_email, resend_confirmation

from flask import Flask
from flask_cors import CORS

application = Flask(__name__)
CORS(application)


# app reference

# This method executes before any API request
@application.before_request
def before_request():
    print("Received request")


# Test route
@application.route('/')
def hello_world():
    return "I am alive!"


# This method returns car park object list
# and by default method will be GET
@application.route('/api/allCarparks')
def get_carpark_list():
    return get_all_carparks()


# This POST method returns single carpark object
@application.route('/api/carpark', methods=['POST'])
def get_carpark_info():
    return getCarparkLotInfo()


# This POST method returns single HDB carpark lot info object
@application.route('/api/HDBLot', methods=['POST'])
def get_HDB_Lot_Info():
    return getHDBLotInfo()


# This POST method returns single URA car park lot info object
@application.route('/api/URALot', methods=['POST'])
def get_URA_Lot_Info():
    return getURALotInfo()


# This POST method returns list of car parks sorted by distance, descending
@application.route('/api/carparksByDistance', methods=['POST'])
def get_carparks_by_distance():
    return get_list_of_carparks_by_distance()


# This POST method returns list of car parks sorted by availability, descending
@application.route('/api/carparksByAvailability', methods=['POST'])
def get_carparks_by_availability():
    return get_list_of_carparks_by_availability()


# This POST method returns list of car parks sorted by cost for 1 hour, descending
@application.route('/api/carparksByCost', methods=['POST'])
def get_carparks_by_cost():
    return get_list_of_carparks_by_cost()


# This POST method registers a user in the database
@application.route('/api/registerUser', methods=['POST'])
def register_user():
    return register()


# This GET method verifies a user account in the database
@application.route('/api/confirmUser/<username>/<token>', methods=['GET'])
def confirm_user(username, token):
    return confirm_email(username, token)


# This GET method resends a verification email for a user in the database
@application.route('/api/reconfirmUser/<username>', methods=['GET'])
def resend_verification(username):
    return resend_confirmation(username)


# This POST method logs in a user
@application.route('/api/loginUser', methods=['POST'])
def login_user():
    return login()


# This GET method retrieves all reviews for a car park
@application.route('/api/getReviews', methods=['GET'])
def get_reviews():
    return getReviews()


# This POST method adds a review to a car park
@application.route('/api/addReview', methods=['POST'])
def add_review():
    return addReview()


# This POST method edits votes to a review for a car park
@application.route('/api/editVotes', methods=['POST'])
def edit_votes():
    return editVotes()


# This POST method calculates the cost of stay at a car park
@application.route('/api/calculate', methods=['POST'])
def calculate_cost():
    return calculateCost()


# This POST method retrieves the rates of the car park
@application.route('/api/rates', methods=['POST'])
def retrieve_rates():
    return getRates()


# This method executes after every API request.
@application.after_request
def after_request(response):
    return response
