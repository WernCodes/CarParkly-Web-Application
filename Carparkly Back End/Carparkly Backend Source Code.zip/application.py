from route_config import *
from flask_bcrypt import Bcrypt

application.debug = False
bcrypt = Bcrypt(application)
# host = os.environ.get('IP', '0.0.0.0')
# port = int(os.environ.get('PORT', 8080))s
if __name__ == '__main__':
    application.run()
