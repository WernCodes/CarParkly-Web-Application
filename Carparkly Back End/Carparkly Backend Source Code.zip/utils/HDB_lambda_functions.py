import botocore
import urllib3
from botocore.exceptions import ClientError

from utils.svy21 import *
from utils.utils import *

dynamodb = dynamodbResource()
HDB_Central_Carparks = ['ACB', 'BBB', 'BRB1', 'CY', 'DUXM', 'HLM', 'KAB', 'KAM', 'KAS', 'PRM', 'SLS', 'SR1', 'SR2',
                        'TPM', 'UCS', 'WCB']


# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# Functions that insert HDB Car park information to database

# Bulk insert data to car park details table
def insert_HDB_data(dataList):
    converter = SVY21()

    table = dynamodb.Table('CarparkDetails')
    with table.batch_writer() as batch:
        for record in dataList:
            is_central = False
            if record['car_park_no'] in HDB_Central_Carparks:
                is_central = True

            lat, lon = converter.computeLatLon(float(record['y_coord']), float(record['x_coord']))
            location = str(lat) + ' ' + str(lon)
            batch.put_item(
                Item={
                    'CarParkID': record['car_park_no'],
                    'Name': record['address'],
                    'Location': location,
                    'Agency': 'HDB',
                    'Details': {
                        'is_central': is_central,
                        'type_of_parking_system': record['type_of_parking_system'],
                        'car_park_type': record['car_park_type'],
                        'car_park_basement': record['car_park_basement'],
                        'car_park_decks': record['car_park_decks'],
                        'gantry_height': record['gantry_height'],
                    },
                    'Rates': {
                        'free_parking': record['free_parking'],
                        'night_parking': record['night_parking'],
                        'short_term_parking': record['short_term_parking'],
                    }
                }
            )


# API call to retrieve HDB Carpark details
def HBD_list_and_rates():

    # API call
    url = "https://data.gov.sg/api/action/datastore_search?resource_id=139a3035-e624-4f56-b63f-89ae28d4ae4c&"
    parameter = "offset="
    currentCount = 0

    http = urllib3.PoolManager()
    while True:
        response = http.request('GET',
                                url + parameter + str(currentCount),
                                headers={'Content-Type': 'application/json'},
                                retries=False)

        print(currentCount)

        if response.status == 200:
            data = json.loads(response.data.decode('utf8'))
            if (len(data['result']['records'])) < 100:
                insert_HDB_data(data['result']['records'])
                return "Done"
            else:
                # Call insert data function to create new records of carparks in dynamodb
                insert_HDB_data(data['result']['records'])
                currentCount += 100


# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
# Functions that help update the number of available lots for HDB car parks

# Put items in HDB table to update lots
def insert_HDB_Lot_data(dictList):
    table = dynamodb.Table('HDB_Lots')
    with table.batch_writer() as batch:
        for key in dictList.keys():
            try:
                batch.put_item(
                    Item={
                        'CarParkID': dictList[key]['carpark_number'],
                        'LotType': dictList[key]['carpark_info'][0]['lot_type'],
                        'TotalLots': dictList[key]['carpark_info'][0]['total_lots'],
                        'AvailableLots': dictList[key]['carpark_info'][0]['lots_available'],
                        'UpdateTime': dictList[key]['update_datetime'],
                    }
                )
            except botocore.exceptions.ClientError as error:
                print(error)
                print(dictList[key])


# API call to retrieve HDB Carpark lot availability
def HDB_lots():
    # API call
    url = "https://api.data.gov.sg/v1/transport/carpark-availability"

    http = urllib3.PoolManager()

    response = http.request('GET',
                            url,
                            headers={'Content-Type': 'application/json'},
                            retries=False)

    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        HDBdict = duplicate_checker_HDB(data['items'][0]['carpark_data'])
        insert_HDB_Lot_data(HDBdict)
        print("Done")


# remove duplicates in HDB availability data, only keeping the lot type == 'C'
def duplicate_checker_HDB(dataList):
    dataDict = {}
    print(len(dataList))
    for record in dataList:
        if (record['carpark_number']) in dataDict.keys():
            continue
        dataDict[record['carpark_number']] = record
    print(len(dataDict))
    return dataDict