import csv
import os
from datetime import datetime


# obtain a time object based on the 12hr format or 24hr format
def convert_to_time_obj(string, timeFormat):
    if timeFormat == '24Hrs':
        return datetime.strptime(string, '%H:%M')
    if timeFormat == '12Hrs':
        try:
            return datetime.strptime(string, '%I%p')
        except:
            try:
                return datetime.strptime(string, '%I.%M%p')
            except:
                return datetime.strptime(string, '%I.%M %p')


# check if a time value lies between the begin and end time
def is_time_between(begin_time, end_time, check_time=None):
    # If check time is not given, default to current UTC time
    check_time = check_time or datetime.utcnow().time()
    if begin_time < end_time:
        return begin_time <= check_time <= end_time
    else:  # crosses midnight
        return check_time >= begin_time or check_time <= end_time


# calculate the time difference between two time objects
def time_difference(begin_time, end_time):
    delta = end_time - begin_time
    if delta.total_seconds() < 0:
        delta = (24 * 60 * 60) + delta.total_seconds()
    else:
        delta = delta.total_seconds()
    return delta / 60


# check the static csv file if today is a public holiday, you will need to change the csv file every year
def check_is_public_holiday():
    now = datetime.now()
    dt_string = now.strftime("%Y-%m-%d")
    util = os.path.dirname(os.path.abspath(__file__))
    file = open(os.path.join(util, "static/public-holidays-for-2022.csv"), "r")
    csvreader = csv.reader(file)
    header = next(csvreader)
    rows = []
    for row in csvreader:
        rows.append(row)
    dates = []
    for date in rows:
        dates.append(date[0])
    if dt_string in dates:
        return True
    else:
        return False
