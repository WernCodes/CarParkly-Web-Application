import os

from utils.carpark_service_utils import *
from utils.utils import *

dynamodb = dynamodbResource()


# function to retrieve one HDB car park object
def retrieve_HDB_carpark_data(carparkId):
    HDBTable = dynamodb.Table('HDB_Lots')
    try:
        response = HDBTable.get_item(
            TableName='HDB_Lots',
            Key={
                'CarParkID': carparkId,
            }
        )

        item = response['Item']
        print(item)
        percentageAvailability, availabilityClassification = define_carpark_availability(int(item['AvailableLots']),
                                                                                         int(item['TotalLots']))
        newResponse = {
            'CarParkID': item['CarParkID'],
            'LotType': item['LotType'],
            'TotalLots': int(item['TotalLots']),
            'AvailableLots': int(item['AvailableLots']),
            'UpdateTime': item['UpdateTime'],
            'PercentageAvailability': round(percentageAvailability, 2),
            'AvailabilityClassification': availabilityClassification
        }
        return newResponse

    except ClientError as e:
        if e.response['Error']['Code'] == 'ProvisionedThroughputExceededException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.\
            print("Item not found in table")
            raise e

        elif e.response['Error']['Code'] == 'RequestLimitExceeded':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServerError':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e


# check if a HDB car park is considered a central car park based on the static txt file
def check_central(carparkId):
    util = os.path.dirname(os.path.abspath(__file__))
    file1 = open(os.path.join(util, "static/HDB_Central_Carparks.txt"), "r")
    list = file1.read()
    if carparkId in list:
        return True
    else:
        return False
