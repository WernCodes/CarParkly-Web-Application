import simplejson as json

import botocore
import urllib3
import boto3
from botocore.exceptions import ClientError
from datetime import datetime

from utils.svy21 import SVY21
from utils.utils import dynamodbResource, get_secret

dynamodb = dynamodbResource()


# //////////////////////////////////////////////////////////////////////////////////////
# Functions to insert URA Car park information to database

# Bulk insert URA car park data into car park details table
def insert_URA_data(dictList):
    table = dynamodb.Table('CarparkDetails')
    with table.batch_writer() as batch:
        for key in dictList.keys():
            batch.put_item(
                Item=dictList[key]
            )


# Create new dictionary with self defined data structure, converted from the api data
def restructure_URA_carpark_data(dataList):
    converter = SVY21()
    result_dict = {}
    for record in dataList:
        if not ('geometries' in record.keys()):
            continue

        if record['ppCode'] in result_dict.keys():
            rate_dict = {'start_time': record['startTime'],
                         'end_time': record['endTime'],
                         'weekday_rate': record['weekdayRate'],
                         'weekday_min': record['weekdayMin'],
                         'satday_rate': record['satdayRate'],
                         'satday_min': record['satdayMin'],
                         'sunPH_rate': record['sunPHRate'],
                         'sunPH_min': record['sunPHMin']}
            if "remarks" in record.keys():
                rate_dict['remarks'] = record['remarks']
            if record['vehCat'] == 'Car':
                result_dict[record['ppCode']]['Rates']['Car'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Car'] = record['parkCapacity']
            if record['vehCat'] == 'Motorcycle':
                result_dict[record['ppCode']]['Rates']['Motorcycle'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Motorcycle'] = record['parkCapacity']
            if record['vehCat'] == 'Heavy Vehicle':
                result_dict[record['ppCode']]['Rates']['Heavy_Vehicle'].append(rate_dict)
                result_dict[record['ppCode']]['TotalLots']['Heavy_Vehicle'] = record['parkCapacity']

        else:
            try:
                coordinates = record['geometries'][0]['coordinates'].split(',')
            except IndexError as e:
                print(e)
                print("Coordinates do not exist, skipping...")
                continue
            lat, lon = converter.computeLatLon(float(coordinates[1]), float(coordinates[0]))
            location = str(lat) + ' ' + str(lon)
            value = {
                'CarParkID': record['ppCode'],
                'Name': record['ppName'],
                'Location': location,
                'TotalLots': {
                    'Car': 0,
                    'Motorcycle': 0,
                    'Heavy_Vehicle': 0
                },
                'Agency': 'URA',
                'Details': {
                    'type_of_parking_system': record['parkingSystem'],
                },
                'Rates': {'Car': [],
                          'Motorcycle': [],
                          'Heavy_Vehicle': []
                          }
            }
            rate_dict = {'start_time': record['startTime'],
                         'end_time': record['endTime'],
                         'weekday_rate': record['weekdayRate'],
                         'weekday_min': record['weekdayMin'],
                         'satday_rate': record['satdayRate'],
                         'satday_min': record['satdayMin'],
                         'sunPH_rate': record['sunPHRate'],
                         'sunPH_min': record['sunPHMin']}
            if "remarks" in record.keys():
                rate_dict['remarks'] = record['remarks']

            if record['vehCat'] == 'Car':
                value['Rates']['Car'].append(rate_dict)
                value['TotalLots']['Car'] = record['parkCapacity']
            if record['vehCat'] == 'Motorcycle':
                value['Rates']['Motorcycle'].append(rate_dict)
                value['TotalLots']['Motorcycle'] = record['parkCapacity']
            if record['vehCat'] == 'Heavy Vehicle':
                value['Rates']['Heavy_Vehicle'].append(rate_dict)
                value['TotalLots']['Heavy_Vehicle'] = record['parkCapacity']
            result_dict[record['ppCode']] = value
    return result_dict


# Obtain the URA carpark details from api
def URA_list_and_rates():
    # calls the function to retrieve secret from aws secret manager, need special role to do this
    secret = json.loads(get_secret("URAAccountKey"))
    URAToken = get_secret("URAToken")
    print(secret)
    print(URAToken)
    # API call
    data_url = "https://www.ura.gov.sg/uraDataService/invokeUraDS?service=Car_Park_Details"
    http = urllib3.PoolManager()

    response = http.request('GET',
                            data_url,
                            headers={'AccessKey': secret['URAAccountKey'],
                                     'Token': URAToken,
                                     'Content-Type': 'application/json'},
                            retries=False)

    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        result = restructure_URA_carpark_data(data['Result'])
        insert_URA_data(result)
        print("Done")


# //////////////////////////////////////////////////////////////////////////////////////
# Functions to insert URA Car park availability to database
# Bulk insert the availability data to table
def insert_URA_Lot_data(dictList):
    table = dynamodb.Table('URA_Lots')
    datatime = datetime.now()
    timestamp = datatime.strftime("%m/%d/%Y, %H:%M:%S")

    with table.batch_writer() as batch:
        for key in dictList.keys():
            try:
                batch.put_item(
                    Item={
                        'CarParkID': key,
                        'AvailableLots': dictList[key]['LotsAvailable'],
                        'UpdateTime': timestamp,
                    }
                )
            except botocore.exceptions.ClientError as error:
                print(error)
                print(dictList[key])


# API call to retrieve URA lot availability data
def URA_lots():
    # calls the function to retrieve secret from aws secret manager, need special role to do this
    secret = json.loads(get_secret("URAAccountKey"))
    URAToken = get_secret("URAToken")

    # API call
    url = "https://www.ura.gov.sg/uraDataService/invokeUraDS?service=Car_Park_Availability"

    http = urllib3.PoolManager()

    response = http.request('GET',
                            url,
                            headers={'AccessKey': secret['URAAccountKey'],
                                     'Token': URAToken,
                                     'Content-Type': 'application/json'},
                            retries=False)

    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        URADataDict = data_restructure_URA(data['Result'])
        insert_URA_Lot_data(URADataDict)
        print("Done")


# Change data structure of data received from API
def data_restructure_URA(dataList):
    dataDict = {}
    for record in dataList:
        if (record['carparkNo']) in dataDict.keys():
            new_data = {record['lotType']: int(record['lotsAvailable'])}
            dataDict[record['carparkNo']]['LotsAvailable'].append(new_data)
        else:
            data = {
                'LotsAvailable': [{record['lotType']: int(record['lotsAvailable'])}]
            }
            dataDict[record['carparkNo']] = data
    return dataDict


# //////////////////////////////////////////////////////////////////////////////////////
# Function to update/obtain URA Token, URA token and URA API Key are needed to call URA APIs.
# URA tokens expire every day thus need to be obtained every day using your URA API key
# URA API Key is permanent and doesnt need to be refreshed

# obtain a new URA token for the day and upload it into AWS
def update_URA_Token():
    # calls the function to retrieve secret from aws secret manager, need special role to do this
    secret = json.loads(get_secret("URAAccountKey"))

    # API call
    url = "https://www.ura.gov.sg/uraDataService/insertNewToken.action"

    http = urllib3.PoolManager()

    response = http.request('GET',
                            url,
                            headers={'AccessKey': secret['URAAccountKey'],
                                     'Content-Type': 'application/json'},
                            retries=False)

    if response.status == 200:
        data = json.loads(response.data.decode('utf8'))
        print(data['Result'])
        push_URA_Token(data['Result'])
        print("Done")


# store the newly obtained URA token into the secrets manager
def push_URA_Token(token):
    region_name = "ap-southeast-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        response = client.update_secret(
            SecretId='URAToken',
            SecretString=token
        )
        print(response)
    except ClientError as e:
        if e.response['Error']['Code'] == 'PreconditionNotMetException':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'LimitExceededException':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'EncryptionFailure':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceExistsException':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
