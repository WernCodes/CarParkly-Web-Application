from botocore.exceptions import ClientError

from utils.carpark_service_utils import define_carpark_availability
from utils.utils import dynamodbResource

dynamodb = dynamodbResource()


# function to retrieve data for a particular car park from dynamodb
def retrieve_URA_carpark_data(carparkId, totalCarLots):
    URATable = dynamodb.Table('URA_Lots')
    try:
        response = URATable.get_item(
            TableName='URA_Lots',
            Key={
                'CarParkID': carparkId,
            }
        )
        try:
            item = response['Item']
        except:
            print("Item may not exist")
            raise ValueError("Item may not exist")

        percentageAvailability, availabilityClassification = define_carpark_availability(
            int(item['AvailableLots'][0]['C']),
            int(totalCarLots))
        newResponse = {
            'CarParkID': item['CarParkID'],
            'TotalLots': int(totalCarLots),
            'AvailableLots': int(item['AvailableLots'][0]['C']),
            'UpdateTime': item['UpdateTime'],
            'PercentageAvailability': round(percentageAvailability, 2),
            'AvailabilityClassification': availabilityClassification
        }
        return newResponse

    except ClientError as e:
        if e.response['Error']['Code'] == 'ProvisionedThroughputExceededException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.\
            print("Item not found in table")
            raise e

        elif e.response['Error']['Code'] == 'RequestLimitExceeded':
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServerError':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
