import math

from utils.date_utils import *

# These variables are hard coded from the HDB website, change them accordingly if need to
peak_rate = 1.2
non_peak_rate = 0.6
night_rate = 0.6


# function to calculate cost of stay at a HDB car park. Some car parks have precise time measurement while some do not
def calculate_cost_HDB(rate, minutes_spent, precise=False):
    if precise:
        return round((minutes_spent / 30) * rate, 2)
    else:
        return round((math.ceil(minutes_spent / 30)) * rate, 2)


# function to calculate cost of stay at a non central HDB car park whose rate is "whole day"
def calculate_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise):
    # by default, whole day means there is night parking
    start_time_night = convert_to_time_obj('10.30PM', '12Hrs')
    end_time_night = convert_to_time_obj('7AM', '12Hrs')
    if timeIn < timeOut:
        # 1st: start and end time <=1030PM
        if not (is_time_between(start_time_night, end_time_night, timeIn)) and not (
                is_time_between(start_time_night, end_time_night, timeOut)):
            time_spent = time_difference(timeIn, timeOut)
            cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
            print(cost)
            return cost

        # 2nd: start time >=1200AM and end time <=7AM or start time>= 1030PM and end time<=1200AM
        elif (is_time_between(start_time_night, end_time_night, timeIn)) and (
                is_time_between(start_time_night, end_time_night, timeOut)) and (
                time_difference(timeIn, timeOut) < 420):
            time_spent_night = time_difference(timeIn, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            print(cost_night)
            return cost_night

        # 3rd: start time >=1200AM endtime >7AM
        elif (is_time_between(start_time_night, end_time_night, timeIn)) and timeOut > end_time_night:
            time_spent_night = time_difference(timeIn, end_time_night)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            time_spent_next_day = time_difference(end_time_night, timeOut)
            cost_next_day = calculate_cost_HDB(non_peak_rate, time_spent_next_day, is_precise)
            cost = cost_night + cost_next_day
            print(cost)
            return cost


        # 4th: start time <=1030PM endtime <1200AM
        elif timeIn < start_time_night <= timeOut:
            time_spent_day = time_difference(timeIn, start_time_night)
            cost_day = calculate_cost_HDB(non_peak_rate, time_spent_day, is_precise)
            time_spent_night = time_difference(start_time_night, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            cost = cost_day + cost_night
            print(cost)
            return cost


    else:
        # 1st: start <1030pm, end <=7am
        if timeIn < start_time_night and timeOut <= end_time_night:
            time_spent_day = time_difference(timeIn, start_time_night)
            cost_day = calculate_cost_HDB(non_peak_rate, time_spent_day, is_precise)
            time_spent_night = time_difference(start_time_night, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            cost = cost_day + cost_night
            print(cost)
            return cost


        # 2nd: start <1030pm, end >7am
        elif timeIn < start_time_night and timeOut > end_time_night:
            time_spent_day = time_difference(timeIn, start_time_night)
            cost_day = calculate_cost_HDB(non_peak_rate, time_spent_day, is_precise)
            time_spent_next_day = time_difference(end_time_night, timeOut)
            cost_next_day = calculate_cost_HDB(non_peak_rate, time_spent_next_day, is_precise)
            cost = cost_day + cost_next_day + night_cap
            print(round(cost, 2))
            return round(cost, 2)

        # 3rd: start >=1030pm, end <7am
        elif timeIn >= start_time_night and timeOut <= end_time_night:
            time_spent = time_difference(timeIn, timeOut)
            # $0.60 per 30 mins, cap at $5
            cost = calculate_cost_HDB(night_rate, time_spent, is_precise)
            if cost > night_cap:
                print('cost is $', night_cap)
                return night_cap
            else:
                print('cost is', cost)
                return cost

        # 4th: start >=1030pm, end >7am
        elif timeIn >= start_time_night and timeOut > end_time_night:
            time_spent_night = time_difference(timeIn, end_time_night)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            time_spent_next_day = time_difference(end_time_night, timeOut)
            cost_next_day = calculate_cost_HDB(non_peak_rate, time_spent_next_day, is_precise)

            cost = cost_night + cost_next_day
            print(cost)
            return cost


# function to calculate cost of stay at a central HDB car park whose rate is "whole day"
def calculate_central_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise):
    start_time_night = convert_to_time_obj('10.30PM', '12Hrs')
    end_time_night = convert_to_time_obj('7AM', '12Hrs')
    end_time_peak = convert_to_time_obj('5PM', '12Hrs')

    if timeIn < timeOut:
        # 1st: start and end time <=1030PM
        if not (is_time_between(start_time_night, end_time_night, timeIn)) and not (
                is_time_between(start_time_night, end_time_night, timeOut)):

            # start and end time <= 5PM, peak cost
            if timeOut <= end_time_peak:
                time_spent = time_difference(timeIn, timeOut)
                cost = calculate_cost_HDB(peak_rate, time_spent, is_precise)
                print(cost)
                return cost

            # start and end time > 5PM
            else:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
                print(cost)
                return cost

        # 2nd: start time >=1200AM and end time <=7AM or start time>= 1030PM and end time<=1200AM
        elif (is_time_between(start_time_night, end_time_night, timeIn)) and (
                is_time_between(start_time_night, end_time_night, timeOut)):
            time_spent_night = time_difference(timeIn, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            print(cost_night)
            return cost_night

        # 3rd: start time >=1200AM endtime >7AM
        elif (is_time_between(start_time_night, end_time_night, timeIn)) and timeOut > end_time_night:
            time_spent_night = time_difference(timeIn, end_time_night)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap

            if timeOut <= end_time_peak:
                time_spent = time_difference(timeIn, timeOut)
                cost = calculate_cost_HDB(peak_rate, time_spent, is_precise)
                print(cost_night + cost)
                return cost_night + cost

            # start and end time > 5PM
            else:
                time_spent_peak = time_difference(end_time_night, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
                print(cost_night + cost)
                return cost_night + cost

        # 4th: start time < 1030PM endtime < 1200AM
        elif timeIn < start_time_night <= timeOut:
            if timeIn > end_time_peak:
                time_spent_non_peak = time_difference(timeIn, start_time_night)
                cost = calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
            else:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, start_time_night)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)

            time_spent_night = time_difference(start_time_night, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            cost += cost_night
            print(cost)
            return cost

    else:
        # 1st: start <1030pm, end <=7am
        if timeIn < start_time_night and timeOut <= end_time_night:
            if timeIn <= end_time_peak:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost_peak = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, start_time_night)
                cost_non_peak = calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
                cost_day = cost_peak + cost_non_peak
            else:
                time_spent_day = time_difference(timeIn, start_time_night)
                cost_day = calculate_cost_HDB(non_peak_rate, time_spent_day, is_precise)

            time_spent_night = time_difference(start_time_night, timeOut)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap
            cost = cost_day + cost_night
            print(cost)
            return cost

        # 2nd: start <1030pm, end >7am
        elif timeIn < start_time_night and timeOut > end_time_night:
            if timeIn <= end_time_peak:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, start_time_night)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
            else:
                time_spent_day = time_difference(timeIn, start_time_night)
                cost = calculate_cost_HDB(non_peak_rate, time_spent_day, is_precise)

            if timeOut <= end_time_peak:
                time_spent_next_day = time_difference(end_time_night, timeOut)
                cost += calculate_cost_HDB(peak_rate, time_spent_next_day, is_precise)
            else:
                time_spent_next_day_peak = time_difference(end_time_night, end_time_peak)
                cost += calculate_cost_HDB(peak_rate, time_spent_next_day_peak, is_precise)
                time_spent_next_day_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_next_day_non_peak, is_precise)

            cost += night_cap
            print(round(cost, 2))
            return round(cost, 2)


        # 3rd: start >=1030pm, end <=7am
        elif timeIn >= start_time_night and timeOut <= end_time_night:
            time_spent = time_difference(timeIn, timeOut)
            # $0.60 per 30 mins, cap at $5
            cost = calculate_cost_HDB(night_rate, time_spent, is_precise)
            if cost > night_cap:
                print('cost is $', night_cap)
                return night_cap

            else:
                print('cost is', cost)
                return cost

        # 4th: start >=1030pm, end >7am
        elif timeIn >= start_time_night and timeOut > end_time_night:
            time_spent_night = time_difference(timeIn, end_time_night)
            cost_night = calculate_cost_HDB(night_rate, time_spent_night, is_precise)
            if cost_night > night_cap:
                cost_night = night_cap

            if timeOut <= end_time_peak:
                time_spent_next_day = time_difference(end_time_night, timeOut)
                cost = calculate_cost_HDB(peak_rate, time_spent_next_day, is_precise)
            else:
                time_spent_next_day_peak = time_difference(end_time_night, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_next_day_peak, is_precise)
                time_spent_next_day_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_next_day_non_peak, is_precise)

            cost += cost_night
            print(cost)
            return cost


# function to calculate cost of stay at a non central car park by providing the exact time window of the rate
def carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise):
    if timeOut < timeIn:
        print('sorry no night parking allowed')
        return None, 'Sorry no night parking allowed'
    # 1st: timeIn and timeOut in between start and end time
    if is_time_between(start_time, end_time, timeIn) and is_time_between(start_time, end_time, timeOut):
        time_spent = time_difference(timeIn, timeOut)
        cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
        print(cost)
        return cost, ''
    # 2nd: return sorry, no night parking allowed
    else:
        print('sorry no night parking allowed')
        # provide the next best time and cost
        if not is_time_between(start_time, end_time, timeIn) and not is_time_between(start_time, end_time, timeOut):
            return None, "Sorry no night parking allowed"
        if is_time_between(start_time, end_time, timeIn) and timeOut > end_time:
            timeOut = end_time
            time_spent = time_difference(timeIn, timeOut)
            cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
            print(cost)
            return cost, ('Sorry you have to leave by ' + end_time.strftime("%H:%M"))
        elif is_time_between(start_time, end_time, timeOut) and timeIn < start_time:
            timeIn = start_time
            time_spent = time_difference(timeIn, timeOut)
            cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
            print(cost)
            return cost, ('Sorry you can only park from ' + start_time.strftime("%H:%M"))


# function to calculate cost of stay at a  central car park by providing the exact time window of the rate
def central_carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise):
    end_time_peak = convert_to_time_obj('5PM', '12Hrs')
    if timeOut < timeIn:
        print('sorry no night parking allowed')
        return None, 'Sorry no night parking allowed'
    # 1st: timeIn and timeOut in between start and end time
    if is_time_between(start_time, end_time, timeIn) and is_time_between(start_time, end_time, timeOut):
        if timeOut <= end_time_peak:
            time_spent = time_difference(timeIn, timeOut)
            cost = calculate_cost_HDB(peak_rate, time_spent, is_precise)
        else:
            if timeIn <= end_time_peak:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
            else:
                time_spent = time_difference(timeIn, timeOut)
                cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
        print(cost)
        return cost, ''
    # 2nd: return sorry, no night parking allowed
    else:
        print('sorry no night parking allowed')
        # provide the next best time and cost
        if not is_time_between(start_time, end_time, timeIn) and not is_time_between(start_time, end_time, timeOut):
            return None, "Sorry no night parking allowed"
        if is_time_between(start_time, end_time, timeIn) and timeOut > end_time:
            timeOut = end_time
            if timeIn <= end_time_peak:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)
            else:
                time_spent = time_difference(timeIn, timeOut)
                cost = calculate_cost_HDB(non_peak_rate, time_spent, is_precise)
            print(cost)
            return cost, ('Sorry you have to leave by ' + end_time.strftime("%H:%M"))
        elif is_time_between(start_time, end_time, timeOut) and timeIn < start_time:
            timeIn = start_time
            if timeOut <= end_time_peak:
                time_spent = time_difference(timeIn, timeOut)
                cost = calculate_cost_HDB(peak_rate, time_spent, is_precise)
            else:
                time_spent_peak = time_difference(timeIn, end_time_peak)
                cost = calculate_cost_HDB(peak_rate, time_spent_peak, is_precise)
                time_spent_non_peak = time_difference(end_time_peak, timeOut)
                cost += calculate_cost_HDB(non_peak_rate, time_spent_non_peak, is_precise)

            print(cost)
            return cost, ('Sorry you can only park from ' + start_time.strftime("%H:%M"))
