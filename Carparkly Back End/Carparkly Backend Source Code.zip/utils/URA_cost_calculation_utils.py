import math
import re
from utils.date_utils import *

from utils.utils import dynamodbResource

dynamodb = dynamodbResource()


def calculate_cost_URA(rate, minutes_spent, type_of_day):
    if type_of_day == 'satday':
        price = float(rate['satday_rate'].strip('$'))
        perDuration = int(re.search(r'\d+', rate['satday_min']).group())
        cost = round((math.ceil(minutes_spent / perDuration)) * price, 2)
        # check for night cap
        if 'cap' in rate:
            if cost > float(rate['cap']['satday_cap'].strip('$')):
                cost = float(rate['cap']['satday_cap'].strip('$'))
        return cost

    elif type_of_day == 'weekday':
        price = float(rate['weekday_rate'].strip('$'))
        perDuration = int(re.search(r'\d+', rate['weekday_min']).group())
        cost = round((math.ceil(minutes_spent / perDuration)) * price, 2)
        # check for night cap
        if 'cap' in rate:
            if cost > float(rate['cap']['weekday_cap'].strip('$')):
                cost = float(rate['cap']['weekday_cap'].strip('$'))
        return cost

    elif type_of_day == 'sunPH':
        price = float(rate['sunPH_rate'].strip('$'))
        perDuration = int(re.search(r'\d+', rate['sunPH_min']).group())
        cost = round((math.ceil(minutes_spent / perDuration)) * price, 2)
        # check for night cap
        if 'cap' in rate:
            if cost > float(rate['cap']['sunPH_cap'].strip('$')):
                cost = float(rate['cap']['sunPH_cap'].strip('$'))
        return cost
    else:
        print('type of day does not exist')


# function to restructure the rates of a URA car park to be more readable
def clean_up_rates(Rates):
    for rate in Rates:
        # convert to 12 hr format
        startTime = convert_to_time_obj(rate['start_time'], '12Hrs')
        endTime = convert_to_time_obj(rate['end_time'], '12Hrs')
        rate['start_time'] = startTime
        rate['end_time'] = endTime
    RatesSorted = sorted(Rates, key=lambda j: (j['start_time'], j['weekday_min']))

    RatesOptimized = []
    i = 0
    while i < len(RatesSorted):
        # if there is only one rate
        if (i + 1) > len(RatesSorted) or len(RatesSorted) == 1:
            RatesOptimized.append(RatesSorted[i])
            i += 1
            continue
        # if there is more than one rate and the start time is the same, this means the other rate is to indicate the max cap cost of stay for that time window
        if RatesSorted[i]['start_time'] == RatesSorted[i + 1]['start_time']:
            RatesSorted[i]['cap'] = {
                'weekday_cap': RatesSorted[i + 1]['weekday_rate'],
                'satday_cap': RatesSorted[i + 1]['satday_rate'],
                'sunPH_cap': RatesSorted[i + 1]['sunPH_rate'],
            }
            RatesOptimized.append(RatesSorted[i])
            i += 2
        else:
            RatesOptimized.append(RatesSorted[i])
            i += 1
    print(RatesOptimized)
    return RatesOptimized


# function to calculate the cost of stay at a URA car park using the cleaned rates
def carpark_cost_URA(RatesCarOptimized, timeIn, timeOut, type_of_day):
    cost = 0

    # time in must be less than time out. This function only calculates length of stay in a day
    if timeIn < timeOut:
        index = 0
        found = False
        for i in range(len(RatesCarOptimized)):
            rate = RatesCarOptimized[i]
            if is_time_between(rate['start_time'], rate['end_time'], timeIn):
                found = True
                if is_time_between(rate['start_time'], rate['end_time'], timeOut):
                    timeSpent = time_difference(timeIn, timeOut)
                    cost += calculate_cost_URA(rate, timeSpent, type_of_day)
                    print(cost)
                    return cost, ''
                else:
                    timeSpent = time_difference(timeIn, rate['end_time'])
                    cost += calculate_cost_URA(rate, timeSpent, type_of_day)
                    index = i
                    break

        # if the time in does not lie in between any of the time windows of the rates for this car park
        if not found:
            print('There seems to be some error in the rates time windows')


        RearrangedRates = RatesCarOptimized[index:] + RatesCarOptimized[:index]
        index = 1

        # calculate the cost based on the start time of the window
        while True:
            if is_time_between(RearrangedRates[index]['start_time'], RearrangedRates[index]['end_time'], timeOut):
                rate = RearrangedRates[index]
                timeSpent = time_difference(rate['start_time'], timeOut)
                cost += calculate_cost_URA(rate, timeSpent, type_of_day)
                print(cost)
                return cost, ''
            else:
                rate = RearrangedRates[index]
                timeSpent = time_difference(rate['start_time'], rate['end_time'])
                cost += calculate_cost_URA(rate, timeSpent, type_of_day)
                index += 1
