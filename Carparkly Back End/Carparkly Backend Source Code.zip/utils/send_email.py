import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail


# send email to user, using the SendGrid API
def send_verification_email(to, subject, url, secondUrl):
    # predefined sendgrid template, you will have to create your own template and get the unique templateid
    templateId = os.environ['SENDGRID_EMAIL_TEMPLATE_ID']
    message = Mail(
        from_email='wng050@e.ntu.edu.sg',
        to_emails=to,
        subject=subject)
    message.template_id = templateId
    message.dynamic_template_data = {
        'url': url,
        'resendURL': secondUrl
    }
    try:
        sg = SendGridAPIClient(os.environ['SENDGRID_API_KEY'])
        response = sg.send(message)
        code, body, headers = response.status_code, response.body, response.headers
        print(f"Response code: {code}")
        print(f"Response headers: {headers}")
        print(f"Response body: {body}")
        print("Email Sent!")
    except Exception as e:
        print(e)
