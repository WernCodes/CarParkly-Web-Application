from flask import request

from utils.utils import *
from boto3.dynamodb.conditions import Key
import uuid
from datetime import datetime

dynamodb = dynamodbResource()
CommunityReviewsTable = dynamodb.Table('Community_Reviews')


# Retrieves array of comments for single carparkID
def getReviews():
    if request.method == 'GET':
        # Get json data from POST request
        carparkId = request.args.get('carparkId')
        username = request.args.get('username')

        response = CommunityReviewsTable.query(
            KeyConditionExpression=Key('CarParkID').eq(carparkId)
        )

        try:
            item = response['Items']
            for review in item:
                if username == "undefined" or username == "null":
                    review['Voted'] = True
                elif username in review['Voted_Users']:
                    review['Voted'] = True
                else:
                    review['Voted'] = False
            print(item)
            return success_response(item,
                                    "Carpark comments returned successfully")
        except:
            # if item does not exist, a different data object would be returned that does not have the field "Items"
            # it would have the field "ResponseMetaData" instead
            return error_response("Item does not exist")

    else:
        return error_response("Invalid method[GET/POST]")


# add review for a carpark
def addReview():
    if request.method == 'POST':
        # Get json data from POST request
        data = request.json
        # generate random UUID for comment sort key
        comment_id = uuid.uuid4()

        try:
            print('adding')
            response = CommunityReviewsTable.put_item(
                Item={
                    'CarParkID': data['carparkId'],
                    'CommentID': str(comment_id),
                    'Username': data['username'],
                    'Review': data['review'],
                    'Rating': data['rating'],
                    'Votes': 0,
                    'Date': datetime.today().strftime('%d-%m-%Y'),
                    'Voted_Users': [data['username']]
                }
            )
            print('done')
            print(response)
            return success_message("Comment successfully added")
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # Composite key already exists in the table, return error
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
            elif e.response['Error']['Code'] == 'InternalServerError':
                # An error occurred on the server side.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
            elif e.response['Error']['Code'] == 'TransactionConflictException':
                # Transaction conflict occurred.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e

    else:
        return error_response("Invalid method[GET/POST]")


# edit votes on a comment
def editVotes():
    if request.method == 'POST':
        # Get json data from POST request
        data = request.json
        try:
            get_response = CommunityReviewsTable.get_item(
                Key={'CarParkID': data['carparkId'], 'CommentID': data['commentId']})
            item = get_response['Item']
            item['Votes'] += data['num']
            print(item)
            if data['username'] not in item['Voted_Users']:
                item['Voted_Users'].append(data['username'])
            else:
                # if the user undoes the vote, a neutral boolean will be sent. User will be able to vote again
                if data['neutral']:
                    item['Voted_Users'].remove(data['username'])
            put_response = CommunityReviewsTable.put_item(
                Item=item)
            print(put_response)
            return success_message("Voted successfully")
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # Composite key already exists in the table, return error
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
            elif e.response['Error']['Code'] == 'InternalServerError':
                # An error occurred on the server side.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
            elif e.response['Error']['Code'] == 'TransactionConflictException':
                # Transaction conflict occurred.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e

    else:
        return error_response("Invalid method[GET/POST]")
