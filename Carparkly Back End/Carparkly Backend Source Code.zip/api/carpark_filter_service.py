# import libraries here

from flask import request

from api.cost_calculator import calculateTemporaryCost
from utils.HDB_Utils import retrieve_HDB_carpark_data
from utils.URA_Utils import retrieve_URA_carpark_data
from utils.carpark_service_utils import getDistanceFromLatLonInKm
from utils.utils import *

dynamodb = dynamodbResource()

# create dynamodb reference to your tables
URATable = dynamodb.Table('URA_Lots')
carparkTable = dynamodb.Table('CarparkDetails')
HDBTable = dynamodb.Table('HDB_Lots')


# retrieves array of carparks within x kilometers of input location
def get_list_of_carparks_by_distance():
    if request.method == 'POST':
        # Get json data from POST request
        jsonInput = request.json
        response = carparkTable.scan()
        data = response['Items']
        carparkArr = []
        while 'LastEvaluatedKey' in response:
            response = carparkTable.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            data.extend(response['Items'])

        for item in data:
            try:
                carparkLatLon = item['Location'].split()
                # retrieve distance to carpark from input location in kilometers
                distance = getDistanceFromLatLonInKm(jsonInput['locationLat'], jsonInput['locationLon'],
                                                     float(carparkLatLon[0]), float(carparkLatLon[1]))
                if distance <= jsonInput['maxDistanceToLocation']:
                    carparkObject = generate_carpark_object(item, distance)
                    carparkArr.append(carparkObject)
            except:
                continue
        sortedArr = sorted(carparkArr, key=lambda i: i['Distance'])
        print(sortedArr)
        return success_response(sortedArr[:10],
                                "Carpark distances returned successfully")
    else:
        return error_response("Invalid method[GET/POST]")


def get_list_of_carparks_by_availability():
    if request.method == 'POST':
        # Get json data from POST request
        jsonInput = request.json
        response = carparkTable.scan()
        data = response['Items']
        carparkArr1 = []
        carparkArr2 = []
        while 'LastEvaluatedKey' in response:
            response = carparkTable.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            data.extend(response['Items'])

        for item in data:
            try:
                carparkLatLon = item['Location'].split()
                # retrieve distance to carpark from input location in kilometers
                distance = getDistanceFromLatLonInKm(jsonInput['locationLat'], jsonInput['locationLon'],
                                                     float(carparkLatLon[0]), float(carparkLatLon[1]))
                if distance <= jsonInput['maxDistanceToLocation']:
                    carparkObject = generate_carpark_object(item, distance)
                    if item['Agency'] == 'LTA':
                        carparkArr1.append(carparkObject)
                    else:
                        carparkArr2.append(carparkObject)
            except:
                continue
        sortedArr = sorted(carparkArr2, key=lambda i: ("AvailableLots" not in i, i.get("AvailableLots", None)),
                           reverse=True)

        # we return max 10 results only
        if len(sortedArr) < 10:

            # if lesser than 10 results, let's append the remaining slots with LTA car parks as they dont have availability data
            sortedArrLTA = sorted(carparkArr1, key=lambda i: i['Distance'])
            sortedArr.extend(sortedArrLTA[:(10 - len(sortedArr))])
        return success_response(sortedArr[:10],
                                "Carpark slots filtered returned successfully")
    else:
        return error_response("Invalid method[GET/POST]")


def get_list_of_carparks_by_cost():
    if request.method == 'POST':
        # Get json data from POST request
        jsonInput = request.json
        response = carparkTable.scan()
        data = response['Items']
        carparkArr = []
        while 'LastEvaluatedKey' in response:
            response = carparkTable.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            data.extend(response['Items'])

        for item in data:
            try:
                carparkLatLon = item['Location'].split()
                # retrieve distance to carpark from input location in kilometers
                distance = getDistanceFromLatLonInKm(jsonInput['locationLat'], jsonInput['locationLon'],
                                                     float(carparkLatLon[0]), float(carparkLatLon[1]))
                if distance <= jsonInput['maxDistanceToLocation']:
                    carparkObject = generate_carpark_object(item, distance)
                    carparkArr.append(carparkObject)
            except:
                continue

        # sort such that only car parks that have an estimated cost are at the top of the list
        sortedArr = sorted(carparkArr, key=lambda i: ("Cost" not in i['TempCost'], i.get("TempCost").get('Cost', None)))
        print(sortedArr)
        return success_response(sortedArr[:10],
                                "Carpark cost filtered returned successfully")
    else:
        return error_response("Invalid method[GET/POST]")


def generate_carpark_object(item, distance):
    if item['Agency'] == 'HDB' or item['Agency'] == 'URA':
        if item['Agency'] == 'HDB':
            lotData = retrieve_HDB_carpark_data(item['CarParkID'])
        else:
            lotData = retrieve_URA_carpark_data(item['CarParkID'], item['TotalLots']['Car'])
        temp_cost = calculateTemporaryCost(item['CarParkID'], 60)
        carparkObject = {'CarParkID': item['CarParkID'],
                         'Location': item['Location'],
                         'Agency': item['Agency'],
                         'TotalLots': int(lotData['TotalLots']),
                         'AvailableLots': int(lotData['AvailableLots']),
                         'Details': item['Details'],
                         'Rates': item['Rates'],
                         'Name': item['Name'],
                         'TempCost': temp_cost,
                         'PercentageAvailability': lotData['PercentageAvailability'],
                         'AvailabilityClassification': lotData['AvailabilityClassification'],
                         'Distance': distance}
        return carparkObject
    elif item['Agency'] == 'LTA':
        carparkObject = {'CarParkID': item['CarParkID'],
                         'Location': item['Location'],
                         'Agency': item['Agency'],
                         'Rates': item['Rates'],
                         'Name': item['Name'],
                         'TempCost': {'Remarks': 'Please refer to cost scheme of car park.'},
                         'Distance': distance}
        return carparkObject