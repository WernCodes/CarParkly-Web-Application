# import libraries here

from flask import request

from utils.HDB_Utils import retrieve_HDB_carpark_data
from utils.URA_Utils import retrieve_URA_carpark_data
from utils.utils import *

dynamodb = dynamodbResource()
URATable = dynamodb.Table('URA_Lots')
carparkTable = dynamodb.Table('CarparkDetails')
HDBTable = dynamodb.Table('HDB_Lots')


# retrieves single carpark document from dynamodb table
def get_carpark(carparkID):
    response = carparkTable.get_item(
        Key={
            'CarParkID': carparkID,
        }
    )
    try:
        item = response['Item']
        return item
    except:
        # if item does not exist, a different data object would be returned that does not have the field "Item"
        # it would have the field "ResponseMetaData" instead
        return error_response("Item does not exist")


# retrieves all carpark documents in dynamodb table, never really used
def get_all_carparks():
    if request.method == 'GET':
        response = carparkTable.scan()
        data = response['Items']
        carparkArr = []
        while 'LastEvaluatedKey' in response:
            response = carparkTable.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            data.extend(response['Items'])
        for item in data:
            try:
                carparkObject = {'CarParkID': item['CarParkID'],
                                 'Location': item['Location'],
                                 'Agency': item['Agency'],
                                 'Rates': item['Rates'],
                                 'Name': item['Name']}
            except:
                print(item)
            carparkArr.append(carparkObject)
        return success_response(carparkArr,
                                "These are the carparks "
                                "stored into records")


# Get a car park's data along with its lot information
def getCarparkLotInfo():
    if request.method == 'POST':
        # Get json data from POST request
        data = request.json
        carpark = get_carpark(data['carparkId'])
        if data['agency'] == 'HDB':
            response = retrieve_HDB_carpark_data(data['carparkId'])
        elif data['agency'] == 'URA':
            response = retrieve_URA_carpark_data(data['carparkId'], carpark['TotalLots']['Car'])
        elif data['agency'] == 'LTA':
            response = {}
        new_response = {
            'Carpark': carpark,
            'LotData': response
        }
        return success_response(new_response, "Carpark Lot info returned successfully")
    else:
        return error_response("Invalid method[GET/POST]")


def getHDBLotInfo():
    if request.method == 'POST':
        # Get json data from POST request
        data = request.json
        response = retrieve_HDB_carpark_data(data['carparkId'])
        return success_response(response, "HDB Lot info returned successfully")
    else:
        return error_response("Invalid method[GET/POST]")


def getURALotInfo():
    if request.method == 'POST':
        # Get json data from POST request
        data = request.json
        URAresponse = URATable.get_item(
            TableName='URA_Lots',
            Key={
                'CarParkID': data['Id'],
            }
        )

        response = carparkTable.get_item(
            Key={
                'CarParkID': data['Id'],
            }
        )
        try:
            # combine total lot info from CarparkDetails table with available lot info from URA_Lots table
            newResponse = {
                "CarParkID": URAresponse['Item']['CarParkID'],
                "AvailableLots": URAresponse['Item']['AvailableLots'],
                "TotalLots": response["Item"]['TotalLots'],
                "UpdateTime": URAresponse['Item']['UpdateTime']
            }
            print(newResponse)
            return success_response(newResponse,
                                    "URA Lot Information returned successfully")
        except:
            # if item does not exist, a different data object would be returned that does not have the field "Item"
            # it would have the field "ResponseMetaData" instead
            return error_response("Item does not exist")
    else:
        return error_response("Invalid method[GET/POST]")
