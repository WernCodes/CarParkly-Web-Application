from flask import request

from api.carpark_service import get_carpark
from utils.HDB_Utils import check_central
from utils.URA_cost_calculation_utils import *
from utils.utils import *
from utils.HDB_cost_calculation_utils import *
import re
from datetime import datetime
from datetime import timedelta

dynamodb = dynamodbResource()
carparkTable = dynamodb.Table('CarparkDetails')

# HDB Night parking cost cap, have to manually change this value based on the HDB Website (but this doesn't change often)
night_cap = 5


# Retrieves the rates of a carpark in a clean format for display
def getRates():
    if request.method == 'POST':
        data = request.json
        carpark = get_carpark(data['carparkId'])
        if carpark['Agency'] == 'HDB':

            # check if this HDB car park is a "central" car park
            is_central = check_central(data['carparkId'])
            rate = {
                "Free Parking": carpark['Rates']['free_parking'],
                "Night Parking": carpark['Rates']['night_parking'],
                "Short Term Parking": carpark['Rates']['short_term_parking'],
            }
            if (is_central):
                rate["Central Car Park?"] = "YES"
            else:
                rate["Central Car Park?"] = "NO"
            print(rate)
            return success_response(rate)

        elif carpark['Agency'] == 'URA':
            RatesCar = carpark['Rates']['Car']
            RatesCarOptimized = clean_up_rates(RatesCar)

            rates_string = []
            for rate in RatesCarOptimized:
                refined_rate = {
                    "From": rate['start_time'].strftime("%H:%M"),
                    "To": rate['end_time'].strftime("%H:%M"),
                    "Weekday Rate": rate['weekday_rate'] + " per " + rate['weekday_min'],
                    "Saturday Rate": rate['satday_rate'] + " per " + rate['satday_min'],
                    "Sunday and Public Holiday Rate": rate['sunPH_rate'] + " per " + rate['sunPH_min']
                }
                if "cap" in rate.keys():
                    refined_rate["Weekday Rate"] = refined_rate["Weekday Rate"] + ", capped at " + rate['cap'][
                        'weekday_cap']
                    refined_rate["Saturday Rate"] = refined_rate["Saturday Rate"] + ", capped at " + rate['cap'][
                        'satday_cap']
                    refined_rate["Sunday and Public Holiday Rate"] = refined_rate[
                                                                         "Sunday and Public Holiday Rate"] + ", capped at " + \
                                                                     rate['cap']['sunPH_cap']

                rates_string.append(refined_rate)
            print(rates_string)
            return success_response(rates_string)
        elif carpark['Agency'] == 'LTA':
            rates_string = []
            for key, value in carpark['Rates'].items():
                rate = {
                    key: value
                }
                rates_string.append(rate)
            return success_response(rates_string)
    else:
        return error_response("Invalid method[GET/POST]")


# calculates car park cost given time in and time out
def calculateCost():
    if request.method == 'POST':
        data = request.json
        carpark = get_carpark(data['carparkId'])

        now = datetime.now()

        timeIn = convert_to_time_obj(data['timeIn'], '24Hrs')
        timeOut = convert_to_time_obj(data['timeOut'], '24Hrs')

        print(now)
        print(now.strftime("%A"))
        print(timeIn)
        print(timeOut)
        if timeIn >= timeOut:
            # error response
            return error_response("We can only calculate for parking in one day.")
        if carpark['Agency'] == 'HDB':
            rates = carpark['Rates']
            parking_system = carpark['Details']['type_of_parking_system']
            is_precise = (parking_system == 'ELECTRONIC PARKING')
            print(parking_system, is_precise)
            is_central = check_central(data['carparkId'])

            if rates['short_term_parking'] == 'NO' and rates['night_parking'] == 'NO' and rates['free_parking'] == 'NO':
                print('sorry no parking here')
                # return sorry no parking here
                return success_response(create_response(0.0),
                                        'Sorry no parking here')

            # if there is free parking for this car park, check what day it is
            if rates['free_parking'] != 'NO':
                if (now.strftime("%A")) == 'Sunday' or check_is_public_holiday():
                    print(rates['free_parking'])
                    start_time_index = re.search(r"\d", rates['free_parking']).start()
                    time_string = rates['free_parking'][start_time_index:]
                    time_values = time_string.split('-')
                    start_time = convert_to_time_obj(time_values[0], '12Hrs')
                    end_time = convert_to_time_obj(time_values[1], '12Hrs')
                    if timeIn < timeOut:
                        # if the time of stay is in between the free parking window
                        if is_time_between(start_time, end_time, timeIn):
                            if is_time_between(start_time, end_time, timeOut):
                                print('Free parking')
                                # check if time is within free period, if not proceed
                                return success_response(create_response(0.0),
                                                        'Free parking')
                            else:
                                timeIn = end_time

                        # if the time of stay exceeds the free parking window
                        elif is_time_between(start_time, end_time, timeOut):
                            timeOut = start_time

                        # if the date of stay is on a free parking day, but the time of stay is not within the free parking window
                        else:
                            if rates['short_term_parking'] == 'NO':
                                if rates['night_parking'] == 'NO':
                                    print(
                                        'sorry have to wait for free parking')  # return sorry have to wait for free parking
                                    return success_response(create_response(0.0),
                                                            'Sorry have to wait for free parking')
                                else:
                                    # check if time is between 1030pm and 7am, if not between return sorry, only night parking avail
                                    start_time = convert_to_time_obj('10.30PM', '12Hrs')
                                    end_time = convert_to_time_obj('7AM', '12Hrs')
                                    if not (is_time_between(start_time, end_time, timeIn)):
                                        print('Sorry you have to wait for night parking at 1030pm')
                                        return success_response(create_response(0.0),
                                                                'Sorry you have to wait for night parking at 1030pm')
                                    else:
                                        if timeOut > end_time:
                                            timeOut = end_time

                                        time_spent = time_difference(timeIn, timeOut)
                                        # $0.60 per 30 mins, cap at $5
                                        cost = calculate_cost_HDB(0.6, time_spent, is_precise)
                                        if cost > night_cap:
                                            print('cost is $', night_cap)
                                            return success_response(create_response(night_cap),
                                                                    "No short term parking after the free window")
                                        else:
                                            print('cost is', cost)
                                            return success_response(create_response(cost),
                                                                    "No short term parking after the free window")

                            # if there is a short term parking cost scheme
                            if rates['short_term_parking'] == 'WHOLE DAY':

                                # the time values for night parking are hard coded, based on the HDB website
                                night_start_time = convert_to_time_obj('10.30PM', '12Hrs')
                                night_end_time = convert_to_time_obj('7AM', '12Hrs')

                                # if the time of stay goes beyond the night parking timing
                                if is_time_between(night_start_time, night_end_time, timeIn) and timeOut > end_time:
                                    if is_central:
                                        cost = calculate_central_carpark_cost_whole_day(timeIn, start_time, night_cap,
                                                                                        is_precise)
                                        cost += calculate_central_carpark_cost_whole_day(end_time, timeOut, night_cap,
                                                                                         is_precise)
                                    else:
                                        cost = calculate_carpark_cost_whole_day(timeIn, start_time, night_cap,
                                                                                is_precise)
                                        cost += calculate_carpark_cost_whole_day(end_time, timeOut, night_cap,
                                                                                 is_precise)
                                    return success_response(create_response(cost))

                    # if time in is >= time out, change the time in to be the end time of the free parking window
                    else:
                        if is_time_between(start_time, end_time, timeIn):
                            timeIn = end_time

            if rates['short_term_parking'] == 'NO':
                if rates['night_parking'] == 'NO':
                    print('sorry have to wait for free parking')  # return sorry have to wait for free parking
                    return success_response(create_response(0.0),
                                            'Sorry have to wait for free parking')
                else:
                    # check if time is between 1030pm and 7am, if not between return sorry, only night parking avail
                    start_time = convert_to_time_obj('10.30PM', '12Hrs')
                    end_time = convert_to_time_obj('7AM', '12Hrs')
                    if not (is_time_between(start_time, end_time, timeIn)):
                        print('Sorry you have to wait for night parking at 1030pm')
                        return success_response(create_response(0.0),
                                                'Sorry you have to wait for night parking at 1030pm')
                    else:
                        if timeOut > end_time:
                            print('There is no short term parking from 7am onwards, you have to leave by 7am')
                            timeOut = end_time

                        time_spent = time_difference(timeIn, timeOut)
                        # $0.60 per 30 mins, cap at $5
                        cost = calculate_cost_HDB(0.6, time_spent, is_precise)
                        if cost > night_cap:
                            print('cost is $', night_cap)
                            return success_response(create_response(night_cap),
                                                    'There is no short term parking from 7am onwards, you have to leave by 7am')
                        else:
                            print('cost is', cost)
                            return success_response(create_response(cost),
                                                    'There is no short term parking from 7am onwards, you have to leave by 7am')

            if rates['short_term_parking'] == 'WHOLE DAY':
                if is_central:
                    cost = calculate_central_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise)
                else:
                    cost = calculate_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise)

                return success_response(create_response(cost))
            else:
                print('in the final else block')
                # by default, anything other than whole day means there is NO night parking
                start_time_index = re.search(r"\d", rates['short_term_parking']).start()
                time_string = rates['short_term_parking'][start_time_index:]
                time_values = time_string.split('-')
                start_time = convert_to_time_obj(time_values[0], '12Hrs')
                end_time = convert_to_time_obj(time_values[1], '12Hrs')
                print(timeIn, timeOut)
                if is_central:
                    cost, remarks = central_carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise)
                else:
                    cost, remarks = carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise)
                return success_response(create_response(cost), remarks)

        if carpark['Agency'] == 'URA':
            RatesCar = carpark['Rates']['Car']
            RatesCarOptimized = clean_up_rates(RatesCar)
            timeInIsValid = False
            timeOutIsValid = False
            for rate in RatesCarOptimized:
                if is_time_between(rate['start_time'], rate['end_time'], timeIn):
                    timeInIsValid = True
                if is_time_between(rate['start_time'], rate['end_time'], timeOut):
                    timeOutIsValid = True

            if not (timeInIsValid and timeOutIsValid):
                # error response, maybe reply with the actual list of timings
                print('parking not available at these timings, please re try with other timings')
                return
            if (now.strftime("%A")) == 'Sunday' or check_is_public_holiday():
                type_of_day = 'sunPH'

            elif now.strftime("%A") == 'Saturday':
                type_of_day = 'satday'

            else:
                type_of_day = 'weekday'
            print(type_of_day)
            cost, remarks = carpark_cost_URA(RatesCarOptimized, timeIn, timeOut, type_of_day)

            return success_response(create_response(cost),
                                    remarks)
    else:
        return error_response("Invalid method[GET/POST]")


# calculates car park cost given time in and time out
def calculateTemporaryCost(carparkId, duration):
    carpark = get_carpark(carparkId)
    now = datetime.now()
    timeIn = now
    timeOut = timeIn + timedelta(minutes=duration)
    timeIn = convert_to_time_obj(timeIn.strftime("%H:%M"), '24Hrs')
    timeOut = convert_to_time_obj(timeOut.strftime("%H:%M"), '24Hrs')
    if timeIn >= timeOut:
        # error response
        return create_temp_response(None, "We can only calculate for parking in one day.")
    if carpark['Agency'] == 'HDB':
        rates = carpark['Rates']
        parking_system = carpark['Details']['type_of_parking_system']
        is_precise = (parking_system == 'ELECTRONIC PARKING')
        is_central = check_central(carparkId)

        if rates['short_term_parking'] == 'NO' and rates['night_parking'] == 'NO' and rates['free_parking'] == 'NO':
            print('sorry no parking here')
            # return sorry no parking here
            return create_temp_response(None, 'Sorry no parking here')

        if rates['free_parking'] != 'NO':
            if (now.strftime("%A")) == 'Sunday' or check_is_public_holiday():
                print(rates['free_parking'])
                start_time_index = re.search(r"\d", rates['free_parking']).start()
                time_string = rates['free_parking'][start_time_index:]
                time_values = time_string.split('-')
                start_time = convert_to_time_obj(time_values[0], '12Hrs')
                end_time = convert_to_time_obj(time_values[1], '12Hrs')
                if timeIn < timeOut:
                    if is_time_between(start_time, end_time, timeIn):
                        if is_time_between(start_time, end_time, timeOut):
                            print('Free parking')
                            # check if time is within free period, if not proceed
                            return create_temp_response(0.0, 'Free parking')
                        else:
                            timeIn = end_time
                    elif is_time_between(start_time, end_time, timeOut):
                        timeOut = start_time
                    else:
                        if rates['short_term_parking'] == 'NO':
                            if rates['night_parking'] == 'NO':
                                print(
                                    'sorry have to wait for free parking')  # return sorry have to wait for free parking
                                return create_temp_response(None, 'Sorry have to wait for free parking')
                            else:
                                # check if time is between 1030pm and 7am, if not between return sorry, only night parking avail
                                start_time = convert_to_time_obj('10.30PM', '12Hrs')
                                end_time = convert_to_time_obj('7AM', '12Hrs')
                                if not (is_time_between(start_time, end_time, timeIn)):
                                    print('Sorry you have to wait for night parking at 1030pm')
                                    return create_temp_response(None,
                                                                'Sorry you have to wait for night parking at 1030pm')
                                else:
                                    if timeOut > end_time:
                                        timeOut = end_time

                                    time_spent = time_difference(timeIn, timeOut)
                                    # $0.60 per 30 mins, cap at $5
                                    cost = calculate_cost_HDB(0.6, time_spent, is_precise)
                                    if cost > night_cap:
                                        print('cost is $', night_cap)
                                        return create_temp_response(night_cap,
                                                                    "No short term parking after the free window")
                                    else:
                                        print('cost is', cost)
                                        return create_temp_response(cost, "No short term parking after the free window")
                        if rates['short_term_parking'] == 'WHOLE DAY':
                            night_start_time = convert_to_time_obj('10.30PM', '12Hrs')
                            night_end_time = convert_to_time_obj('7AM', '12Hrs')
                            if is_time_between(night_start_time, night_end_time, timeIn) and timeOut > end_time:
                                if is_central:
                                    cost = calculate_central_carpark_cost_whole_day(timeIn, start_time, night_cap,
                                                                                    is_precise)
                                    cost += calculate_central_carpark_cost_whole_day(end_time, timeOut, night_cap,
                                                                                     is_precise)
                                else:
                                    cost = calculate_carpark_cost_whole_day(timeIn, start_time, night_cap,
                                                                            is_precise)
                                    cost += calculate_carpark_cost_whole_day(end_time, timeOut, night_cap,
                                                                             is_precise)
                                return create_temp_response(cost, "")

                else:
                    if is_time_between(start_time, end_time, timeIn):
                        timeIn = end_time

        if rates['short_term_parking'] == 'NO':
            if rates['night_parking'] == 'NO':
                print('sorry have to wait for free parking')  # return sorry have to wait for free parking
                return create_temp_response(None, 'Sorry have to wait for free parking')
            else:
                # check if time is between 1030pm and 7am, if not between return sorry, only night parking avail
                start_time = convert_to_time_obj('10.30PM', '12Hrs')
                end_time = convert_to_time_obj('7AM', '12Hrs')
                if not (is_time_between(start_time, end_time, timeIn)):
                    print('Sorry you have to wait for night parking at 1030pm')
                    return create_temp_response(None, 'Sorry you have to wait for night parking at 1030pm')
                else:
                    if timeOut > end_time:
                        print('There is no short term parking from 7am onwards, you have to leave by 7am')
                        timeOut = end_time

                    time_spent = time_difference(timeIn, timeOut)
                    # $0.60 per 30 mins, cap at $5, this rate is hard coded from the HDB website
                    cost = calculate_cost_HDB(0.6, time_spent, is_precise)
                    if cost > night_cap:
                        print('cost is $', night_cap)
                        return create_temp_response(night_cap,
                                                    'There is no short term parking from 7am onwards, you have to leave by 7am')
                    else:
                        print('cost is', cost)
                        return create_temp_response(cost,
                                                    'There is no short term parking from 7am onwards, you have to leave by 7am')

        if rates['short_term_parking'] == 'WHOLE DAY':
            if is_central:
                cost = calculate_central_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise)
            else:
                cost = calculate_carpark_cost_whole_day(timeIn, timeOut, night_cap, is_precise)

            return create_temp_response(cost, "")
        else:
            # by default, anything other than whole day means there is NO night parking
            start_time_index = re.search(r"\d", rates['short_term_parking']).start()
            time_string = rates['short_term_parking'][start_time_index:]
            time_values = time_string.split('-')
            start_time = convert_to_time_obj(time_values[0], '12Hrs')
            end_time = convert_to_time_obj(time_values[1], '12Hrs')
            if is_central:
                cost, remarks = central_carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise)
            else:
                cost, remarks = carpark_cost_window(timeIn, timeOut, start_time, end_time, is_precise)
            return create_temp_response(cost, remarks)

    if carpark['Agency'] == 'URA':
        RatesCar = carpark['Rates']['Car']
        RatesCarOptimized = clean_up_rates(RatesCar)

        # boolean values to check if the time in and time out lies within a time window of a rate for the car park
        timeInIsValid = False
        timeOutIsValid = False
        for rate in RatesCarOptimized:
            if is_time_between(rate['start_time'], rate['end_time'], timeIn):
                timeInIsValid = True
            if is_time_between(rate['start_time'], rate['end_time'], timeOut):
                timeOutIsValid = True

        if not (timeInIsValid and timeOutIsValid):
            # error response, maybe reply with the actual list of timings
            print('Parking not available at these timings, please re try with other timings')
            return create_temp_response(None, "Parking not available at this timing")
        if (now.strftime("%A")) == 'Sunday' or check_is_public_holiday():
            type_of_day = 'sunPH'

        elif now.strftime("%A") == 'Saturday':
            type_of_day = 'satday'

        else:
            type_of_day = 'weekday'
        print(type_of_day)
        cost, remarks = carpark_cost_URA(RatesCarOptimized, timeIn, timeOut, type_of_day)

        return create_temp_response(cost, remarks)


def create_response(cost):
    response = {
        'Cost': cost
    }
    return response


def create_temp_response(cost, remarks):
    if cost is None:
        response = {
            'Remarks': remarks
        }
    else:
        response = {
            'Cost': cost,
            'Remarks': remarks
        }
    return response
