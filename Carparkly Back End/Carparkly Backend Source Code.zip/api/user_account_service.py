import os

from botocore.exceptions import ClientError
from flask import request, render_template, url_for

from utils.send_email import send_verification_email
from utils.utils import *

from utils.utils import dynamodbResource
from flask_bcrypt import Bcrypt
from itsdangerous import URLSafeTimedSerializer
from datetime import datetime

dynamodb = dynamodbResource()
UsersTable = dynamodb.Table('Users')
bcrypt = Bcrypt()

# function to create a user account
def register():
    if request.method == 'POST':
        data = request.json
        # we only store hashed passwords for security purposes
        hashed_pw = bcrypt.generate_password_hash(data['password']).decode('utf-8')

        try:
            response = UsersTable.put_item(
                Item={
                    'Username': data['username'],
                    'Email': data['email'],
                    'FirstName': data['first_name'],
                    'LastName': data['last_name'],
                    'Password': hashed_pw,
                    'Confirmed': False,
                    'ConfirmedOn': "",
                },
                ConditionExpression='attribute_not_exists(Username)',
            )
            # generate unique token that expires in 1 hour
            token = generate_confirmation_token(data['email'])

            # url for user to click to validate their email
            confirm_url = os.environ['BACKEND_DOMAIN'] + '/api/confirmUser/' + data['username'] + '/' + token

            # url for user to click if the validation url expired and they need another token
            reconfirm_url = os.environ['BACKEND_DOMAIN'] + '/api/reconfirmUser/' + data['username']

            subject = "Please confirm your email with Carparkly"
            send_verification_email(data['email'], subject, confirm_url, reconfirm_url)
            return success_message("Account successfully created, please check your email and click verification link")
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # UserID already exists in the table, return error
                # Deal with the exception here, and/or rethrow at your discretion.
                print("Account already exists, please try again")
                return error_response("Account already exists, please try again")
            elif e.response['Error']['Code'] == 'InternalServerError':
                # An error occurred on the server side.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
            elif e.response['Error']['Code'] == 'TransactionConflictException':
                # Transaction conflict occurred.
                # Deal with the exception here, and/or rethrow at your discretion.
                raise e
    else:
        return error_response("Invalid method[GET/POST]")

# function to login users
def login():
    if request.method == 'POST':
        data = request.json

        # Get json data from POST request
        response = UsersTable.get_item(
            Key={
                'Username': data['username'],
            }
        )
        try:
            item = response['Item']
            print(item)
            if not item['Confirmed']:
                return error_response("Account is not verified, please verify via email.", 401)

            if bcrypt.check_password_hash(item['Password'], data['password']):
                response_object = {
                    'Username': item['Username']
                }
                return success_response(response_object,
                                        "These is the user logged in")
            else:
                return error_response("Wrong login info")
        except:
            # if item does not exist, a different data object would be returned that does not have the field "Item"
            # it would have the field "ResponseMetaData" instead
            return error_response("User does not exist")
    else:
        return error_response("Invalid method[GET/POST]")


# generate token for user to use when verifying email
def generate_confirmation_token(email):
    serializer = URLSafeTimedSerializer(os.environ['SECRET_KEY'])
    return serializer.dumps(email, salt=os.environ['SECURITY_PASSWORD_SALT'])


# checks if token provided is valid or expired, default expiry is 1 hour
def confirm_token(token, expiration=3600):
    serializer = URLSafeTimedSerializer(os.environ['SECRET_KEY'])
    try:
        email = serializer.loads(
            token,
            salt=os.environ['SECURITY_PASSWORD_SALT'],
            max_age=expiration
        )
    except:
        return False
    return email


# resends a new confirmation email to user
def resend_confirmation(username):
    if request.method == 'GET':
        # retrieve user object from database
        response = UsersTable.get_item(
            Key={
                'Username': username,
            }
        )
        item = response['Item']
        token = generate_confirmation_token(item['Email'])
        confirm_url = url_for('confirm_user', username=username, token=token, _external=True)
        reconfirm_url = url_for('resend_verification', username=username, _external=True)
        subject = "Please confirm your email with Carparkly"
        send_verification_email(item['Email'], subject, confirm_url, reconfirm_url)
        return render_template('email_verification_sent_template.html')
    else:
        return error_response("Invalid method[GET/POST]")

# function to validate a user once they clicks on the confirmation url that was sent to their email
def confirm_email(username, token):
    if request.method == 'GET':
        try:
            email = confirm_token(token)
        except:
            return error_response('The confirmation link is invalid or has expired.')

        # token is not valid because it has expired, thus email will be assigned False
        if not email:
            return render_template('email_token_expired_template.html')

        # token is valid, proceed to retrieve user object
        response = UsersTable.get_item(
            Key={
                'Username': username,
            }
        )
        try:
            user = response['Item']
            print(user)
        except:
            print("User does not exist")

        # check if user has already been confirmed, if so render html
        if user['Confirmed']:
            return render_template('email_already_verified_template.html')

        # if user has not yet been confirmed, set the Confirmed and ConfirmedOn attributes
        else:
            response = UsersTable.update_item(
                Key={
                    'Username': username
                },
                UpdateExpression="set Confirmed=:a, ConfirmedOn=:t",
                ConditionExpression='attribute_exists(Username)',
                ExpressionAttributeValues={
                    ':a': True,
                    ':t': datetime.now().strftime('%d-%m-%Y %H:%M:%S')
                },
                ReturnValues="UPDATED_NEW"
            )
            return render_template('email_success_template.html')
    else:
        return error_response("Invalid method[GET/POST]")
