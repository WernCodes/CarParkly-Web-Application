# import libraries here

import boto3

# chagne the endpoint url accordingly if you want to change where your data ends up (local vs cloud)
dynamodb = boto3.resource('dynamodb', endpoint_url='http://localhost:8000')


# function for inserting data into dynamodb table
def insert_LTA_data(dataList):
    table = dynamodb.Table('CarparkDetails')
    with table.batch_writer() as batch:
        for i in range(len(dataList)):
            record = dataList[i]
            print(record)
            batch.put_item(
                Item={
                    'CarParkID': record['CarParkID'],
                    'Name': record['Name'],
                    'Location': record['Location'],
                    'Agency': 'LTA',
                    'Rates': record['Rates']
                }
            )
